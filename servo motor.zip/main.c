#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pwm.h"

#define SERVO_PIN 22
#define LED_PIN 12
#define FREQ 50 // Frequência de 50Hz (Período de 20ms)

void set_duty_cycle(uint slice_num, int microseconds) {
    uint16_t wrap = 12500; // Para 50Hz com clock de 1.25MHz
    uint16_t duty = (microseconds * wrap) / 20000;
    pwm_set_gpio_level(slice_num, duty);
}

void move_smooth(uint slice_num, int start, int end, int step, int delay_ms) {
    if (start < end) {
        for (int pulse = start; pulse <= end; pulse += step) {
            set_duty_cycle(slice_num, pulse);
            sleep_ms(delay_ms);
        }
    } else {
        for (int pulse = start; pulse >= end; pulse -= step) {
            set_duty_cycle(slice_num, pulse);
            sleep_ms(delay_ms);
        }
    }
}

int main() {
    stdio_init_all();
    gpio_set_function(SERVO_PIN, GPIO_FUNC_PWM);
    gpio_set_function(LED_PIN, GPIO_FUNC_PWM);
    
    uint slice_servo = pwm_gpio_to_slice_num(SERVO_PIN);
    uint slice_led = pwm_gpio_to_slice_num(LED_PIN);
    
    pwm_set_wrap(slice_servo, 12500);
    pwm_set_clkdiv(slice_servo, 64);
    pwm_set_enabled(slice_servo, true);
    
    pwm_set_wrap(slice_led, 12500);
    pwm_set_clkdiv(slice_led, 64);
    pwm_set_enabled(slice_led, true);
    
    // Passos iniciais
    set_duty_cycle(slice_servo, 2400); // 180 graus
    set_duty_cycle(slice_led, 12500); // LED brilho máximo
    sleep_ms(5000);
    
    set_duty_cycle(slice_servo, 1470); // 90 graus
    set_duty_cycle(slice_led, 6250); // LED meia intensidade
    sleep_ms(5000);
    
    set_duty_cycle(slice_servo, 500); // 0 graus
    set_duty_cycle(slice_led, 2500); // LED baixa intensidade
    sleep_ms(5000);
    
    // Movimento suave entre 0 e 180 graus
    while (1) {
        move_smooth(slice_servo, 500, 2400, 5, 10); // 0° -> 180°
        move_smooth(slice_servo, 2400, 500, 5, 10); // 180° -> 0°
    }
    
    return 0;
}
